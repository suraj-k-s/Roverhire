
        <!-- footer  -->
        <!-- jquery slim -->
        <script src="../Assets/Template/Admin/js/jquery-3.4.1.min.js"></script>
        <!-- popper js -->
        <script src="../Assets/Template/Admin/js/popper.min.js"></script>
        <!-- bootstarp js -->
        <script src="../Assets/Template/Admin/js/bootstrap.min.js"></script>
        <!-- sidebar menu  -->
        <script src="../Assets/Template/Admin/js/metisMenu.js"></script>
        <!-- waypoints js -->
        <script src="../Assets/Template/Admin/vendors/count_up/jquery.waypoints.min.js"></script>
        <!-- waypoints js -->
        <script src="../Assets/Template/Admin/vendors/chartlist/Chart.min.js"></script>
        <!-- counterup js -->
        <script src="../Assets/Template/Admin/vendors/count_up/jquery.counterup.min.js"></script>
        <!-- swiper slider js -->
        <script src="../Assets/Template/Admin/vendors/swiper_slider/js/swiper.min.js"></script>
        <!-- nice select -->
        <script src="../Assets/Template/Admin/vendors/niceselect/js/jquery.nice-select.min.js"></script>
        <!-- owl carousel -->
        <script src="../Assets/Template/Admin/vendors/owl_carousel/js/owl.carousel.min.js"></script>
        <!-- gijgo css -->
        <script src="../Assets/Template/Admin/vendors/gijgo/gijgo.min.js"></script>
        <!-- responsive table -->
        <script src="../Assets/Template/Admin/vendors/datatable/js/jquery.dataTables.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/dataTables.responsive.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/dataTables.buttons.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/buttons.flash.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/jszip.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/pdfmake.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/vfs_fonts.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/buttons.html5.min.js"></script>
        <script src="../Assets/Template/Admin/vendors/datatable/js/buttons.print.min.js"></script>

        <script src="../Assets/Template/Admin/js/chart.min.js"></script>
        <!-- progressbar js -->
        <script src="../Assets/Template/Admin/vendors/progressbar/jquery.barfiller.js"></script>
        <!-- tag input -->
        <script src="../Assets/Template/Admin/vendors/tagsinput/tagsinput.js"></script>
        <!-- text editor js -->
        <script src="../Assets/Template/Admin/vendors/text_editor/summernote-bs4.js"></script>

        <script src="../Assets/Template/Admin/vendors/apex_chart/apexcharts.js"></script>

        <!-- custom js -->
        <script src="../Assets/Template/Admin/js/custom.js"></script>

        <script src="../Assets/Template/Admin/vendors/apex_chart/bar_active_1.js"></script>
        <script src="../Assets/Template/Admin/vendors/apex_chart/apex_chart_list.js"></script>
    </body>
</html>